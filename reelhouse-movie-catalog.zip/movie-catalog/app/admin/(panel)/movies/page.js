import AdminMoviesTable from "@/components/admin/AdminMoviesTable";

export const metadata = { title: "Movies" };

export default function AdminMoviesPage() {
  return (
    <div>
      <h1 className="mb-6 text-2xl text-bone">Manage movies</h1>
      <AdminMoviesTable />
    </div>
  );
}

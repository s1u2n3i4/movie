import MovieCard from "./MovieCard";

export default function MovieGrid({ movies = [], emptyMessage = "No movies found." }) {
  if (!movies.length) {
    return (
      <div className="card flex flex-col items-center justify-center gap-2 py-16 text-center">
        <p className="text-lg font-medium text-bone">Nothing here yet</p>
        <p className="max-w-sm text-sm text-smoke">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
      {movies.map((m) => (
        <MovieCard key={m._id || m.slug} movie={m} />
      ))}
    </div>
  );
}

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getGenres, getSettings } from "@/lib/data";

export default async function SiteLayout({ children }) {
  const [genres, settings] = await Promise.all([getGenres(), getSettings()]);

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar genres={genres} />
      <main className="flex-1">{children}</main>
      <Footer copyrightNotice={settings.copyrightNotice} />
    </div>
  );
}

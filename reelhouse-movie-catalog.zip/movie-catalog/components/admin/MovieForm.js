"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import toast from "react-hot-toast";
import { UploadCloud, Plus, X, ShieldAlert } from "lucide-react";
import { apiFetch } from "@/lib/apiClient";

const LANGUAGES = ["English", "Hindi", "Spanish", "French", "German", "Japanese", "Korean", "Other"];
const RIGHTS_OPTIONS = [
  { value: "owned", label: "We own this content" },
  { value: "licensed", label: "Licensed from the rights holder" },
  { value: "public-domain", label: "Public domain" },
  { value: "creator-permission", label: "Published with creator's permission" },
];

function emptyForm() {
  return {
    title: "",
    slug: "",
    description: "",
    posterUrl: "",
    backdropUrl: "",
    releaseYear: new Date().getFullYear(),
    language: "English",
    genres: [],
    runtime: 90,
    rating: 0,
    quality: "HD",
    director: "",
    cast: [],
    trailerUrl: "",
    videoUrl: "",
    country: "",
    tags: [],
    rightsStatus: "",
    licenseNote: "",
    rightsConfirmed: false,
    featured: false,
    status: "draft",
  };
}

export default function MovieForm({ genres, initialMovie, mode }) {
  const router = useRouter();
  const [form, setForm] = useState(() =>
    initialMovie
      ? {
          ...emptyForm(),
          ...initialMovie,
          genres: initialMovie.genres.map((g) => (typeof g === "string" ? g : g._id)),
        }
      : emptyForm()
  );
  const [castInput, setCastInput] = useState({ name: "", role: "" });
  const [tagInput, setTagInput] = useState("");
  const [uploading, setUploading] = useState({ poster: false, backdrop: false });
  const [saving, setSaving] = useState(false);

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function toggleGenre(id) {
    setForm((f) => ({
      ...f,
      genres: f.genres.includes(id) ? f.genres.filter((g) => g !== id) : [...f.genres, id],
    }));
  }

  async function handleUpload(field, file) {
    if (!file) return;
    setUploading((u) => ({ ...u, [field]: true }));
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd, credentials: "same-origin" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      set(field, data.url);
      toast.success("Image uploaded");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setUploading((u) => ({ ...u, [field]: false }));
    }
  }

  function addCast() {
    if (!castInput.name.trim()) return;
    set("cast", [...form.cast, { ...castInput, name: castInput.name.trim() }]);
    setCastInput({ name: "", role: "" });
  }

  function removeCast(i) {
    set("cast", form.cast.filter((_, idx) => idx !== i));
  }

  function addTag() {
    const t = tagInput.trim();
    if (!t || form.tags.includes(t)) return;
    set("tags", [...form.tags, t]);
    setTagInput("");
  }

  function removeTag(t) {
    set("tags", form.tags.filter((x) => x !== t));
  }

  async function submit(e, targetStatus) {
    e.preventDefault();
    const payload = { ...form, status: targetStatus };

    if (targetStatus === "published" && !payload.rightsConfirmed) {
      toast.error("Confirm the legal rights checkbox before publishing.");
      return;
    }

    setSaving(true);
    try {
      if (mode === "add") {
        const { movie } = await apiFetch("/api/movies", { method: "POST", body: JSON.stringify(payload) });
        toast.success(targetStatus === "published" ? "Movie published." : "Draft saved.");
        router.push(`/admin/movies/${movie.slug}/edit`);
        router.refresh();
      } else {
        await apiFetch(`/api/movies/${initialMovie.slug}`, { method: "PUT", body: JSON.stringify(payload) });
        toast.success("Movie updated.");
        router.refresh();
      }
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="space-y-8">
      <section className="card space-y-4 p-5">
        <h2 className="text-lg text-bone">Basics</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="label">Title</label>
            <input className="input" value={form.title} onChange={(e) => set("title", e.target.value)} required />
          </div>
          <div>
            <label className="label">Slug (leave blank to auto-generate)</label>
            <input className="input" value={form.slug} onChange={(e) => set("slug", e.target.value)} placeholder="auto-generated-from-title" />
          </div>
        </div>
        <div>
          <label className="label">Description</label>
          <textarea className="input min-h-28" value={form.description} onChange={(e) => set("description", e.target.value)} required />
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div>
            <label className="label">Release year</label>
            <input type="number" className="input" value={form.releaseYear} onChange={(e) => set("releaseYear", Number(e.target.value))} required />
          </div>
          <div>
            <label className="label">Runtime (min)</label>
            <input type="number" className="input" value={form.runtime} onChange={(e) => set("runtime", Number(e.target.value))} required />
          </div>
          <div>
            <label className="label">Rating (0–10)</label>
            <input type="number" step="0.1" min="0" max="10" className="input" value={form.rating} onChange={(e) => set("rating", Number(e.target.value))} />
          </div>
          <div>
            <label className="label">Quality label</label>
            <input className="input" value={form.quality} onChange={(e) => set("quality", e.target.value)} placeholder="HD, 4K, SD…" />
          </div>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div>
            <label className="label">Language</label>
            <select className="input" value={form.language} onChange={(e) => set("language", e.target.value)}>
              {LANGUAGES.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Country</label>
            <input className="input" value={form.country} onChange={(e) => set("country", e.target.value)} />
          </div>
          <div>
            <label className="label">Director</label>
            <input className="input" value={form.director} onChange={(e) => set("director", e.target.value)} />
          </div>
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-lg text-bone">Images</h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <ImageField label="Poster" url={form.posterUrl} uploading={uploading.poster} onUpload={(f) => handleUpload("posterUrl", f)} aspect="aspect-[2/3]" />
          <ImageField label="Backdrop" url={form.backdropUrl} uploading={uploading.backdrop} onUpload={(f) => handleUpload("backdropUrl", f)} aspect="aspect-video" />
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-lg text-bone">Genres</h2>
        <div className="flex flex-wrap gap-2">
          {genres.map((g) => (
            <button
              type="button"
              key={g._id}
              onClick={() => toggleGenre(g._id)}
              className={`badge ${form.genres.includes(g._id) ? "border-marquee bg-marquee/10 text-marquee" : "hover:border-marquee/50"}`}
            >
              {g.name}
            </button>
          ))}
          {genres.length === 0 && <p className="text-sm text-smoke">Add a genre first from the Genres page.</p>}
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-lg text-bone">Cast</h2>
        <div className="flex flex-wrap gap-2">
          {form.cast.map((c, i) => (
            <span key={i} className="badge flex items-center gap-1.5">
              {c.name}{c.role ? ` (${c.role})` : ""}
              <button type="button" onClick={() => removeCast(i)}><X className="h-3 w-3" /></button>
            </span>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <input className="input max-w-[200px]" placeholder="Actor name" value={castInput.name} onChange={(e) => setCastInput((c) => ({ ...c, name: e.target.value }))} />
          <input className="input max-w-[160px]" placeholder="Role (optional)" value={castInput.role} onChange={(e) => setCastInput((c) => ({ ...c, role: e.target.value }))} />
          <button type="button" onClick={addCast} className="btn-secondary"><Plus className="h-4 w-4" /> Add</button>
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-lg text-bone">Tags</h2>
        <div className="flex flex-wrap gap-2">
          {form.tags.map((t) => (
            <span key={t} className="badge flex items-center gap-1.5">
              {t} <button type="button" onClick={() => removeTag(t)}><X className="h-3 w-3" /></button>
            </span>
          ))}
        </div>
        <div className="flex gap-2">
          <input className="input max-w-xs" value={tagInput} onChange={(e) => setTagInput(e.target.value)} placeholder="e.g. indie, classic, animated" />
          <button type="button" onClick={addTag} className="btn-secondary"><Plus className="h-4 w-4" /> Add tag</button>
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-lg text-bone">Streaming</h2>
        <div>
          <label className="label">Authorized video/stream URL</label>
          <input className="input" value={form.videoUrl} onChange={(e) => set("videoUrl", e.target.value)} placeholder="https://…" required />
          <p className="mt-1 text-xs text-smoke">Must point to a source you're authorized to stream from — no unauthorized download links.</p>
        </div>
        <div>
          <label className="label">Trailer URL (optional)</label>
          <input className="input" value={form.trailerUrl} onChange={(e) => set("trailerUrl", e.target.value)} placeholder="https://youtube.com/…" />
        </div>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="flex items-center gap-2 text-lg text-bone"><ShieldAlert className="h-5 w-5 text-marquee" /> Rights & licensing</h2>
        <div>
          <label className="label">Legal basis for publishing</label>
          <select className="input" value={form.rightsStatus} onChange={(e) => set("rightsStatus", e.target.value)} required>
            <option value="">Select…</option>
            {RIGHTS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
        <div>
          <label className="label">License note (agreement ref, PD source, etc.)</label>
          <input className="input" value={form.licenseNote} onChange={(e) => set("licenseNote", e.target.value)} />
        </div>
        <label className="flex items-start gap-2 text-sm text-smoke">
          <input type="checkbox" className="mt-1" checked={form.rightsConfirmed} onChange={(e) => set("rightsConfirmed", e.target.checked)} />
          I confirm the site owner holds the legal right to publish and stream this title.
        </label>
      </section>

      <section className="card space-y-4 p-5">
        <h2 className="text-lg text-bone">Visibility</h2>
        <label className="flex items-center gap-2 text-sm text-smoke">
          <input type="checkbox" checked={form.featured} onChange={(e) => set("featured", e.target.checked)} />
          Feature on homepage
        </label>
      </section>

      <div className="flex gap-3 pb-10">
        <button type="button" disabled={saving} onClick={(e) => submit(e, "draft")} className="btn-secondary">
          {saving ? "Saving…" : "Save as draft"}
        </button>
        <button type="button" disabled={saving} onClick={(e) => submit(e, "published")} className="btn-primary">
          {saving ? "Publishing…" : "Publish"}
        </button>
      </div>
    </form>
  );
}

function ImageField({ label, url, uploading, onUpload, aspect }) {
  return (
    <div>
      <label className="label">{label}</label>
      <div className={`relative ${aspect} w-full max-w-[220px] overflow-hidden rounded-card border border-dashed border-line bg-panel2`}>
        {url ? (
          <Image src={url} alt={label} fill className="object-cover" />
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-1 text-smoke">
            <UploadCloud className="h-6 w-6" />
            <span className="text-xs">{uploading ? "Uploading…" : "No image yet"}</span>
          </div>
        )}
      </div>
      <input
        type="file"
        accept="image/jpeg,image/png,image/webp,image/avif"
        onChange={(e) => onUpload(e.target.files?.[0])}
        className="mt-2 text-xs text-smoke file:mr-3 file:rounded-md file:border-0 file:bg-panel2 file:px-3 file:py-1.5 file:text-bone hover:file:bg-line"
      />
    </div>
  );
}

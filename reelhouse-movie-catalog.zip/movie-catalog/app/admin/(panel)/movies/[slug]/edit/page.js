import { notFound } from "next/navigation";
import MovieForm from "@/components/admin/MovieForm";
import { getGenres } from "@/lib/data";
import { connectDB } from "@/lib/db";
import Movie from "@/models/Movie";

export const metadata = { title: "Edit Movie" };

export default async function EditMoviePage({ params }) {
  await connectDB();
  const [movie, genres] = await Promise.all([
    Movie.findOne({ slug: params.slug }).populate("genres", "name slug").lean(),
    getGenres(),
  ]);
  if (!movie) notFound();

  const initialMovie = JSON.parse(JSON.stringify(movie));

  return (
    <div>
      <h1 className="mb-6 text-2xl text-bone">Edit movie — {movie.title}</h1>
      <MovieForm genres={genres} initialMovie={initialMovie} mode="edit" />
    </div>
  );
}

/**
 * Creates the first superadmin account, using SEED_ADMIN_* from .env.local.
 * Run with: npm run seed:admin
 *
 * Defaults to username "admin" / password "admin123" if not overridden —
 * CHANGE THIS PASSWORD IMMEDIATELY after your first login (Admin > Users
 * or the change-password endpoint). Never use these defaults in production.
 */
require("dotenv").config({ path: ".env.local" });
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

async function main() {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("MONGODB_URI is not set (check .env.local).");

  const username = (process.env.SEED_ADMIN_USERNAME || "admin").toLowerCase();
  const email = (process.env.SEED_ADMIN_EMAIL || "admin@example.com").toLowerCase();
  const password = process.env.SEED_ADMIN_PASSWORD || "admin123";

  await mongoose.connect(uri);

  const AdminSchema = new mongoose.Schema(
    {
      username: { type: String, required: true, unique: true, lowercase: true },
      email: { type: String, required: true, unique: true, lowercase: true },
      passwordHash: { type: String, required: true },
      role: { type: String, enum: ["superadmin", "admin", "editor"], default: "admin" },
      isActive: { type: Boolean, default: true },
      lastLoginAt: { type: Date },
    },
    { timestamps: true }
  );
  const Admin = mongoose.models.Admin || mongoose.model("Admin", AdminSchema);

  const existing = await Admin.findOne({ $or: [{ username }, { email }] });
  if (existing) {
    console.log(`An admin with username "${username}" or email "${email}" already exists. Nothing to do.`);
    await mongoose.disconnect();
    return;
  }

  const passwordHash = await bcrypt.hash(password, 12);
  await Admin.create({ username, email, passwordHash, role: "superadmin", isActive: true });

  console.log("First superadmin created:");
  console.log(`  username: ${username}`);
  console.log(`  password: ${password}`);
  console.log("Log in at /admin/login, then change this password right away.");

  await mongoose.disconnect();
}

main().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});

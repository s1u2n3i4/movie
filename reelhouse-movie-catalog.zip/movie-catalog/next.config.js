/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "res.cloudinary.com" },
      { protocol: "https", hostname: "**" }, // narrow this in production to your image host(s)
    ],
  },
  eslint: { ignoreDuringBuilds: false },
};

module.exports = nextConfig;

import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Movie from "@/models/Movie";
import { requireAdmin } from "@/lib/requireAdmin";

// PATCH /api/movies/:slug/toggle  body: { field: "status" | "featured" }
// Flips status between draft/published, or featured true/false.
export async function PATCH(request, { params }) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin", "editor"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  if (!body || !["status", "featured"].includes(body.field)) {
    return NextResponse.json({ error: "field must be 'status' or 'featured'." }, { status: 400 });
  }

  await connectDB();
  const movie = await Movie.findOne({ slug: params.slug });
  if (!movie) return NextResponse.json({ error: "Movie not found." }, { status: 404 });

  if (body.field === "status") {
    const next = movie.status === "published" ? "draft" : "published";
    if (next === "published" && !movie.rightsConfirmed) {
      return NextResponse.json(
        { error: "Cannot publish: rights have not been confirmed for this title." },
        { status: 400 }
      );
    }
    movie.status = next;
  } else {
    movie.featured = !movie.featured;
  }

  await movie.save();
  return NextResponse.json({ movie });
}

import mongoose from "mongoose";

// Singleton document (findOne, no filter) holding site-wide configuration
// that the admin can edit without a redeploy.
const SettingsSchema = new mongoose.Schema(
  {
    siteName: { type: String, default: "Reelhouse" },
    tagline: { type: String, default: "Licensed & public-domain films, streamed the right way." },
    contactEmail: { type: String, default: "" },
    copyrightNotice: {
      type: String,
      default:
        "All titles on this site are streamed under license, direct ownership, creator permission, or public-domain status. Report a rights concern to the contact email above.",
    },
  },
  { timestamps: true }
);

export default mongoose.models.Settings || mongoose.model("Settings", SettingsSchema);

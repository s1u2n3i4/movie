import { Bebas_Neue, Inter } from "next/font/google";
import "./globals.css";
import ToastProvider from "@/components/ToastProvider";

const display = Bebas_Neue({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-display",
  display: "swap",
});

const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

const siteName = process.env.NEXT_PUBLIC_SITE_NAME || "Reelhouse";
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: `${siteName} — Licensed films, streamed properly`, template: `%s — ${siteName}` },
  description:
    "A catalog of legally owned, licensed, and public-domain films, streamed through authorized sources only.",
  openGraph: {
    siteName,
    type: "website",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body>
        <ToastProvider />
        {children}
      </body>
    </html>
  );
}

export default function StatCard({ label, value, icon: Icon }) {
  return (
    <div className="card flex items-center gap-4 p-5">
      {Icon && (
        <div className="flex h-11 w-11 items-center justify-center rounded-md bg-marquee/10 text-marquee">
          <Icon className="h-5 w-5" />
        </div>
      )}
      <div>
        <p className="text-2xl font-semibold text-bone">{value}</p>
        <p className="text-sm text-smoke">{label}</p>
      </div>
    </div>
  );
}

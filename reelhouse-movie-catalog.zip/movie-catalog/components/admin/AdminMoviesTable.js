"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import toast from "react-hot-toast";
import { Search, Star, Pencil, Trash2, Eye, EyeOff } from "lucide-react";
import { apiFetch } from "@/lib/apiClient";

export default function AdminMoviesTable() {
  const [movies, setMovies] = useState([]);
  const [genres, setGenres] = useState([]);
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("");
  const [language, setLanguage] = useState("");
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const sp = new URLSearchParams({ status: "all", page: String(page), limit: "15" });
      if (query) sp.set("query", query);
      if (genre) sp.set("genre", genre);
      if (language) sp.set("language", language);
      const data = await apiFetch(`/api/movies?${sp.toString()}`);
      setMovies(data.items);
      setPages(data.pages);
      setTotal(data.total);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }, [query, genre, language, page]);

  useEffect(() => {
    apiFetch("/api/genres").then((d) => setGenres(d.genres)).catch(() => {});
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function toggle(slug, field) {
    try {
      const { movie } = await apiFetch(`/api/movies/${slug}/toggle`, {
        method: "PATCH",
        body: JSON.stringify({ field }),
      });
      setMovies((ms) => ms.map((m) => (m.slug === slug ? { ...m, ...movie } : m)));
      toast.success(field === "status" ? `Now ${movie.status}` : movie.featured ? "Featured" : "Unfeatured");
    } catch (err) {
      toast.error(err.message);
    }
  }

  async function remove(slug, title) {
    if (!confirm(`Delete "${title}"? This can't be undone.`)) return;
    try {
      await apiFetch(`/api/movies/${slug}`, { method: "DELETE" });
      toast.success("Movie deleted.");
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-smoke" />
          <input
            className="input pl-9"
            placeholder="Search movies…"
            value={query}
            onChange={(e) => { setPage(1); setQuery(e.target.value); }}
          />
        </div>
        <select className="input w-auto" value={genre} onChange={(e) => { setPage(1); setGenre(e.target.value); }}>
          <option value="">All genres</option>
          {genres.map((g) => <option key={g.slug} value={g.slug}>{g.name}</option>)}
        </select>
        <select className="input w-auto" value={language} onChange={(e) => { setPage(1); setLanguage(e.target.value); }}>
          <option value="">All languages</option>
          {[...new Set(movies.map((m) => m.language))].map((l) => <option key={l} value={l}>{l}</option>)}
        </select>
        <span className="text-sm text-smoke">{total} total</span>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="border-b border-line text-left text-smoke">
            <tr>
              <th className="p-3 font-medium">Title</th>
              <th className="p-3 font-medium">Year</th>
              <th className="p-3 font-medium">Language</th>
              <th className="p-3 font-medium">Status</th>
              <th className="p-3 font-medium">Featured</th>
              <th className="p-3 font-medium">Views</th>
              <th className="p-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {loading && (
              <tr><td colSpan={7} className="p-6 text-center text-smoke">Loading…</td></tr>
            )}
            {!loading && movies.length === 0 && (
              <tr><td colSpan={7} className="p-6 text-center text-smoke">No movies match those filters.</td></tr>
            )}
            {movies.map((m) => (
              <tr key={m._id}>
                <td className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="relative h-12 w-9 shrink-0 overflow-hidden rounded bg-panel2">
                      {m.posterUrl && <Image src={m.posterUrl} alt="" fill className="object-cover" />}
                    </div>
                    <span className="text-bone">{m.title}</span>
                  </div>
                </td>
                <td className="p-3 text-smoke">{m.releaseYear}</td>
                <td className="p-3 text-smoke">{m.language}</td>
                <td className="p-3">
                  <button onClick={() => toggle(m.slug, "status")} className={`badge ${m.status === "published" ? "border-marquee/50 text-marquee" : ""}`}>
                    {m.status === "published" ? <Eye className="mr-1 inline h-3 w-3" /> : <EyeOff className="mr-1 inline h-3 w-3" />}
                    {m.status}
                  </button>
                </td>
                <td className="p-3">
                  <button onClick={() => toggle(m.slug, "featured")} className={`badge ${m.featured ? "border-marquee/50 text-marquee" : ""}`}>
                    <Star className={`mr-1 inline h-3 w-3 ${m.featured ? "fill-marquee" : ""}`} />
                    {m.featured ? "Featured" : "Not featured"}
                  </button>
                </td>
                <td className="p-3 text-smoke">{m.views}</td>
                <td className="p-3">
                  <div className="flex justify-end gap-2">
                    <Link href={`/admin/movies/${m.slug}/edit`} className="btn-secondary px-2.5 py-1.5"><Pencil className="h-3.5 w-3.5" /></Link>
                    <button onClick={() => remove(m.slug, m.title)} className="btn-danger"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {pages > 1 && (
        <div className="mt-3 flex justify-center gap-2">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-secondary disabled:opacity-40">Prev</button>
          <button disabled={page >= pages} onClick={() => setPage((p) => p + 1)} className="btn-secondary disabled:opacity-40">Next</button>
        </div>
      )}
    </div>
  );
}

import Link from "next/link";
import Hero from "@/components/Hero";
import SectionHeader from "@/components/SectionHeader";
import MovieGrid from "@/components/MovieGrid";
import {
  getFeaturedMovies,
  getLatestMovies,
  getPopularMovies,
  getGenres,
  getYears,
} from "@/lib/data";

export const revalidate = 60;

export default async function HomePage() {
  const [featured, latest, popular, genres, years] = await Promise.all([
    getFeaturedMovies(6),
    getLatestMovies(12),
    getPopularMovies(12),
    getGenres(),
    getYears(8),
  ]);

  return (
    <div>
      <Hero movie={featured[0]} />

      <div className="mx-auto max-w-7xl space-y-14 px-4 py-12 sm:px-6">
        {featured.length > 1 && (
          <section>
            <SectionHeader title="Featured" href="/search?featured=true" />
            <MovieGrid movies={featured} emptyMessage="No featured titles yet." />
          </section>
        )}

        <section>
          <SectionHeader title="Latest additions" href="/search?sort=newest" />
          <MovieGrid movies={latest} emptyMessage="No movies published yet — check back soon." />
        </section>

        <section>
          <SectionHeader title="Most popular" href="/search?sort=popular" />
          <MovieGrid movies={popular} emptyMessage="Popularity rankings will appear once movies get views." />
        </section>

        <section>
          <SectionHeader title="Browse by genre" />
          <div className="flex flex-wrap gap-2">
            {genres.map((g) => (
              <Link
                key={g.slug}
                href={`/genre/${g.slug}`}
                className="badge hover:border-marquee/60 hover:text-marquee"
              >
                {g.name}
              </Link>
            ))}
            {!genres.length && <p className="text-sm text-smoke">No genres added yet.</p>}
          </div>
        </section>

        <section>
          <SectionHeader title="Browse by year" />
          <div className="flex flex-wrap gap-2">
            {years.map((y) => (
              <Link
                key={y}
                href={`/search?year=${y}`}
                className="badge hover:border-marquee/60 hover:text-marquee"
              >
                {y}
              </Link>
            ))}
            {!years.length && <p className="text-sm text-smoke">No release years to show yet.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}

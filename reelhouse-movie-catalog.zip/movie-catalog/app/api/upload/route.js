import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/requireAdmin";
import { uploadImage } from "@/lib/cloudinary";

const MAX_BYTES = 8 * 1024 * 1024; // 8MB
const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp", "image/avif"];

// POST /api/upload — admin only. Expects multipart/form-data with a "file"
// field (poster or backdrop image). Returns the hosted URL to save on the movie.
export async function POST(request) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin", "editor"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const formData = await request.formData().catch(() => null);
  const file = formData?.get("file");
  if (!file || typeof file === "string") {
    return NextResponse.json({ error: "No file uploaded." }, { status: 400 });
  }

  if (!ALLOWED_MIME.includes(file.type)) {
    return NextResponse.json({ error: "Only JPEG, PNG, WebP, or AVIF images are allowed." }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: "Image must be under 8MB." }, { status: 400 });
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  const dataUrl = `data:${file.type};base64,${bytes.toString("base64")}`;

  try {
    const { url, publicId } = await uploadImage(dataUrl);
    return NextResponse.json({ url, publicId });
  } catch (err) {
    return NextResponse.json({ error: "Image upload failed. Check Cloudinary credentials." }, { status: 500 });
  }
}

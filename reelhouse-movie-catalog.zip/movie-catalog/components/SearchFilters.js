"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const LANGUAGES = ["English", "Hindi", "Spanish", "French", "German", "Japanese", "Korean", "Other"];

export default function SearchFilters({ genres, years, current }) {
  const router = useRouter();
  const [query, setQuery] = useState(current.query || "");

  function update(partial) {
    const sp = new URLSearchParams(current);
    Object.entries(partial).forEach(([k, v]) => {
      if (v) sp.set(k, v);
      else sp.delete(k);
    });
    sp.delete("page");
    router.push(`/search?${sp.toString()}`);
  }

  return (
    <div className="card mb-6 grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          update({ query });
        }}
        className="lg:col-span-2"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by title…"
          className="input"
        />
      </form>

      <select className="input" value={current.genre || ""} onChange={(e) => update({ genre: e.target.value })}>
        <option value="">All genres</option>
        {genres.map((g) => (
          <option key={g.slug} value={g.slug}>{g.name}</option>
        ))}
      </select>

      <select className="input" value={current.language || ""} onChange={(e) => update({ language: e.target.value })}>
        <option value="">All languages</option>
        {LANGUAGES.map((l) => (
          <option key={l} value={l}>{l}</option>
        ))}
      </select>

      <select className="input" value={current.year || ""} onChange={(e) => update({ year: e.target.value })}>
        <option value="">All years</option>
        {years.map((y) => (
          <option key={y} value={y}>{y}</option>
        ))}
      </select>

      <select className="input lg:col-span-5" value={current.sort || "newest"} onChange={(e) => update({ sort: e.target.value })}>
        <option value="newest">Newest first</option>
        <option value="popular">Most popular</option>
        <option value="rating">Highest rated</option>
        <option value="year">Release year</option>
        <option value="title">Title (A–Z)</option>
      </select>
    </div>
  );
}

import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Movie from "@/models/Movie";
import Genre from "@/models/Genre";
import Admin from "@/models/Admin";
import { requireAdmin } from "@/lib/requireAdmin";

export async function GET() {
  const { admin, error, status } = await requireAdmin();
  if (!admin) return NextResponse.json({ error }, { status });

  await connectDB();

  const [totalMovies, totalGenres, totalAdmins, recentMovies, mostViewed, published, drafts] =
    await Promise.all([
      Movie.countDocuments(),
      Genre.countDocuments(),
      Admin.countDocuments(),
      Movie.find().sort({ createdAt: -1 }).limit(6).select("title slug posterUrl status createdAt").lean(),
      Movie.find({ status: "published" })
        .sort({ views: -1 })
        .limit(6)
        .select("title slug posterUrl views")
        .lean(),
      Movie.countDocuments({ status: "published" }),
      Movie.countDocuments({ status: "draft" }),
    ]);

  return NextResponse.json({
    totals: { movies: totalMovies, genres: totalGenres, admins: totalAdmins, published, drafts },
    recentMovies,
    mostViewed,
  });
}

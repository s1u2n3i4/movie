import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Admin from "@/models/Admin";
import { requireAdmin } from "@/lib/requireAdmin";
import { adminCreateSchema } from "@/lib/validation";

// GET /api/admin/users — superadmin only.
export async function GET() {
  const { admin, error, status } = await requireAdmin(["superadmin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  await connectDB();
  const admins = await Admin.find().select("-passwordHash").sort({ createdAt: -1 }).lean();
  return NextResponse.json({ admins });
}

// POST /api/admin/users — superadmin only. Creates a new admin/editor account.
export async function POST(request) {
  const { admin, error, status } = await requireAdmin(["superadmin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  const parsed = adminCreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
  }
  const { username, email, password, role } = parsed.data;

  await connectDB();
  const exists = await Admin.findOne({
    $or: [{ username: username.toLowerCase() }, { email: email.toLowerCase() }],
  });
  if (exists) {
    return NextResponse.json({ error: "Username or email already in use." }, { status: 409 });
  }

  const newAdmin = new Admin({ username: username.toLowerCase(), email: email.toLowerCase(), role });
  await newAdmin.setPassword(password);
  await newAdmin.save();

  return NextResponse.json(
    { admin: { username: newAdmin.username, email: newAdmin.email, role: newAdmin.role } },
    { status: 201 }
  );
}

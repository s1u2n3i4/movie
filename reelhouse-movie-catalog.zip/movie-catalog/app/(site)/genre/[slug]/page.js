import { notFound } from "next/navigation";
import SectionHeader from "@/components/SectionHeader";
import MovieGrid from "@/components/MovieGrid";
import Pagination from "@/components/Pagination";
import { getGenreBySlug, getMoviesByFilter } from "@/lib/data";

export async function generateMetadata({ params }) {
  const genre = await getGenreBySlug(params.slug);
  if (!genre) return { title: "Genre not found" };
  return {
    title: `${genre.name} movies`,
    description: `Browse licensed and public-domain ${genre.name.toLowerCase()} movies.`,
  };
}

export default async function GenrePage({ params, searchParams }) {
  const genre = await getGenreBySlug(params.slug);
  if (!genre) notFound();

  const page = Math.max(1, Number(searchParams.page || 1));
  const { items, pages } = await getMoviesByFilter({
    genre: params.slug,
    page,
    limit: 24,
    sort: searchParams.sort || "newest",
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <SectionHeader title={`${genre.name} movies`} />
      <MovieGrid movies={items} emptyMessage={`No published ${genre.name.toLowerCase()} titles yet.`} />
      <Pagination page={page} pages={pages} buildHref={(p) => `/genre/${params.slug}?page=${p}`} />
    </div>
  );
}

import { toEmbedUrl, isDirectVideoFile } from "@/lib/embed";
import { ShieldCheck } from "lucide-react";

export default function VideoPlayer({ url, title }) {
  const embed = toEmbedUrl(url);
  const direct = isDirectVideoFile(url);

  return (
    <div>
      <div className="aspect-video w-full overflow-hidden rounded-card border border-line bg-panel2">
        {embed ? (
          <iframe
            src={embed}
            title={title}
            className="h-full w-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        ) : direct ? (
          <video controls className="h-full w-full" poster="">
            <source src={url} />
            Your browser does not support embedded video.
          </video>
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center text-smoke">
            <p>This title streams from an external authorized provider.</p>
            <a href={url} target="_blank" rel="noopener noreferrer" className="btn-primary">
              Watch on provider site
            </a>
          </div>
        )}
      </div>
      <p className="mt-2 flex items-center gap-1.5 text-xs text-smoke">
        <ShieldCheck className="h-3.5 w-3.5 text-marquee" />
        Streamed from an authorized source. No unauthorized downloads are provided.
      </p>
    </div>
  );
}

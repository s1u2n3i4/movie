import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Admin from "@/models/Admin";
import { requireAdmin } from "@/lib/requireAdmin";
import { adminPasswordChangeSchema } from "@/lib/validation";

export async function POST(request) {
  const { admin, error, status } = await requireAdmin();
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  const parsed = adminPasswordChangeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
  }

  await connectDB();
  const fresh = await Admin.findById(admin._id);
  const valid = await fresh.verifyPassword(parsed.data.currentPassword);
  if (!valid) {
    return NextResponse.json({ error: "Current password is incorrect." }, { status: 401 });
  }

  await fresh.setPassword(parsed.data.newPassword);
  await fresh.save();

  return NextResponse.json({ ok: true });
}

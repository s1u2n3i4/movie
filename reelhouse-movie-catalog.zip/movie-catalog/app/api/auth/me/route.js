import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/requireAdmin";

export async function GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ admin: null }, { status: 200 });
  return NextResponse.json({
    admin: { username: admin.username, email: admin.email, role: admin.role },
  });
}

import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-ink px-4 text-center text-bone">
      <span className="font-display text-7xl text-marquee">404</span>
      <h1 className="text-2xl">This reel is missing</h1>
      <p className="max-w-sm text-smoke">
        The page you're looking for doesn't exist, or the title may have been unpublished.
      </p>
      <Link href="/" className="btn-primary">Back to homepage</Link>
    </div>
  );
}

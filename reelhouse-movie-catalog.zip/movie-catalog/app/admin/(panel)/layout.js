import { redirect } from "next/navigation";
import { getCurrentAdmin } from "@/lib/requireAdmin";
import AdminSidebar from "@/components/admin/AdminSidebar";

export const metadata = { title: "Admin", robots: { index: false, follow: false } };

export default async function AdminPanelLayout({ children }) {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");

  const plainAdmin = { username: admin.username, role: admin.role };

  return (
    <div className="flex min-h-screen bg-ink">
      <AdminSidebar admin={plainAdmin} />
      <div className="flex-1 overflow-x-hidden">
        <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
      </div>
    </div>
  );
}

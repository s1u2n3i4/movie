import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Movie from "@/models/Movie";
import Genre from "@/models/Genre";
import { requireAdmin } from "@/lib/requireAdmin";
import { movieSchema } from "@/lib/validation";
import { uniqueSlug, toSlug } from "@/lib/slug";

// GET /api/movies?query=&genre=&language=&year=&page=&limit=&sort=&featured=&status=
// Public by default (published only). Pass a valid admin session + status=all
// to list drafts too (used by the admin table).
export async function GET(request) {
  await connectDB();
  const { searchParams } = new URL(request.url);

  const query = searchParams.get("query")?.trim();
  const genre = searchParams.get("genre");
  const language = searchParams.get("language");
  const year = searchParams.get("year");
  const featured = searchParams.get("featured");
  const status = searchParams.get("status");
  const sort = searchParams.get("sort") || "newest";
  const page = Math.max(1, Number(searchParams.get("page") || 1));
  const limit = Math.min(48, Number(searchParams.get("limit") || 20));

  const filter = {};

  // Only an authenticated admin may request non-published/all statuses.
  if (status === "all" || status === "draft") {
    const { admin } = await requireAdmin();
    if (!admin) {
      filter.status = "published";
    } else if (status === "draft") {
      filter.status = "draft";
    }
    // status === "all" + valid admin => no status filter at all
  } else {
    filter.status = "published";
  }

  if (query) filter.$text = { $search: query };
  if (genre) {
    const g = await Genre.findOne({ slug: genre });
    if (g) filter.genres = g._id;
    else filter.genres = { $in: [] }; // no such genre -> empty result set
  }
  if (language) filter.language = language;
  if (year) filter.releaseYear = Number(year);
  if (featured === "true") filter.featured = true;

  const sortMap = {
    newest: { createdAt: -1 },
    popular: { views: -1 },
    rating: { rating: -1 },
    year: { releaseYear: -1 },
    title: { title: 1 },
  };

  const [items, total] = await Promise.all([
    Movie.find(filter)
      .populate("genres", "name slug")
      .sort(sortMap[sort] || sortMap.newest)
      .skip((page - 1) * limit)
      .limit(limit)
      .lean(),
    Movie.countDocuments(filter),
  ]);

  return NextResponse.json({
    items,
    total,
    page,
    pages: Math.ceil(total / limit) || 1,
  });
}

// POST /api/movies — admin only. Creates a new movie; refuses to publish
// unless the rights attestation fields are present and confirmed.
export async function POST(request) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin", "editor"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  const parsed = movieSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Invalid movie data", issues: parsed.error.issues },
      { status: 400 }
    );
  }

  const data = parsed.data;

  // Hard legal gate, enforced server-side regardless of what the client sent.
  if (data.status === "published" && !data.rightsConfirmed) {
    return NextResponse.json(
      { error: "Cannot publish a movie without confirming legal rights to stream it." },
      { status: 400 }
    );
  }

  await connectDB();

  const genreDocs = await Genre.find({ _id: { $in: data.genres } });
  if (genreDocs.length !== data.genres.length) {
    return NextResponse.json({ error: "One or more genres are invalid." }, { status: 400 });
  }

  const baseForSlug = data.slug ? data.slug : toSlug(data.title);
  const slug = await uniqueSlug(baseForSlug, (candidate) =>
    Movie.exists({ slug: candidate })
  );

  try {
    const movie = await Movie.create({ ...data, slug });
    return NextResponse.json({ movie }, { status: 201 });
  } catch (err) {
    if (err?.code === 11000) {
      return NextResponse.json({ error: "A movie with that slug already exists." }, { status: 409 });
    }
    return NextResponse.json({ error: "Failed to create movie." }, { status: 500 });
  }
}

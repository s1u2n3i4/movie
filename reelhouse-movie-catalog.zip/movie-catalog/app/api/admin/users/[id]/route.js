import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Admin from "@/models/Admin";
import { requireAdmin } from "@/lib/requireAdmin";

const ROLES = ["superadmin", "admin", "editor"];

// PUT /api/admin/users/:id  body: { role?, isActive? } — superadmin only.
export async function PUT(request, { params }) {
  const { admin, error, status } = await requireAdmin(["superadmin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid request body." }, { status: 400 });

  await connectDB();
  const target = await Admin.findById(params.id);
  if (!target) return NextResponse.json({ error: "Admin not found." }, { status: 404 });

  if (target._id.equals(admin._id) && body.role && body.role !== "superadmin") {
    return NextResponse.json({ error: "You can't demote your own account." }, { status: 400 });
  }

  if (body.role) {
    if (!ROLES.includes(body.role)) {
      return NextResponse.json({ error: "Invalid role." }, { status: 400 });
    }
    target.role = body.role;
  }
  if (typeof body.isActive === "boolean") {
    if (target._id.equals(admin._id) && body.isActive === false) {
      return NextResponse.json({ error: "You can't deactivate your own account." }, { status: 400 });
    }
    target.isActive = body.isActive;
  }

  await target.save();
  return NextResponse.json({
    admin: { username: target.username, email: target.email, role: target.role, isActive: target.isActive },
  });
}

// DELETE /api/admin/users/:id — superadmin only.
export async function DELETE(_request, { params }) {
  const { admin, error, status } = await requireAdmin(["superadmin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  if (params.id === admin._id.toString()) {
    return NextResponse.json({ error: "You can't remove your own account." }, { status: 400 });
  }

  await connectDB();
  const deleted = await Admin.findByIdAndDelete(params.id);
  if (!deleted) return NextResponse.json({ error: "Admin not found." }, { status: 404 });

  return NextResponse.json({ ok: true });
}

import Link from "next/link";
import Image from "next/image";
import { Star } from "lucide-react";

export default function MovieCard({ movie }) {
  const genreNames = (movie.genres || []).map((g) => g.name).slice(0, 2).join(", ");

  return (
    <Link
      href={`/movie/${movie.slug}`}
      className="group block overflow-hidden rounded-card border border-line bg-panel transition hover:-translate-y-1 hover:border-marquee/50 hover:shadow-card"
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-panel2">
        {movie.posterUrl ? (
          <Image
            src={movie.posterUrl}
            alt={`${movie.title} poster`}
            fill
            sizes="(max-width: 640px) 45vw, (max-width: 1024px) 25vw, 16vw"
            className="object-cover transition duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-smoke">No poster</div>
        )}
        <span className="absolute left-2 top-2 badge bg-ink/80">{movie.quality || "HD"}</span>
        {movie.rating > 0 && (
          <span className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-ink/80 px-2 py-0.5 text-xs font-medium text-marquee">
            <Star className="h-3 w-3 fill-marquee" /> {movie.rating.toFixed(1)}
          </span>
        )}
      </div>
      <div className="p-3">
        <h3 className="truncate font-medium text-bone group-hover:text-marquee">{movie.title}</h3>
        <p className="mt-1 truncate text-xs text-smoke">
          {movie.releaseYear} · {movie.language}
          {genreNames ? ` · ${genreNames}` : ""}
        </p>
      </div>
    </Link>
  );
}

import SectionHeader from "@/components/SectionHeader";
import MovieGrid from "@/components/MovieGrid";
import Pagination from "@/components/Pagination";
import SearchFilters from "@/components/SearchFilters";
import { getMoviesByFilter, getGenres, getYears } from "@/lib/data";

export const metadata = {
  title: "Search",
  description: "Search the catalog by title, genre, language, or year.",
};

export default async function SearchPage({ searchParams }) {
  const page = Math.max(1, Number(searchParams.page || 1));
  const { query, genre, language, year, sort } = searchParams;

  const [{ items, pages, total }, genres, years] = await Promise.all([
    getMoviesByFilter({ query, genre, language, year, sort, page, limit: 24 }),
    getGenres(),
    getYears(20),
  ]);

  const buildHref = (p) => {
    const sp = new URLSearchParams({ ...searchParams, page: String(p) });
    return `/search?${sp.toString()}`;
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <SectionHeader title={query ? `Results for "${query}"` : "Browse all movies"} />

      <SearchFilters genres={genres} years={years} current={searchParams} />

      <p className="mb-4 text-sm text-smoke">{total} title{total === 1 ? "" : "s"} found</p>

      <MovieGrid
        movies={items}
        emptyMessage="Try a different title, genre, language, or year — or clear your filters."
      />
      <Pagination page={page} pages={pages} buildHref={buildHref} />
    </div>
  );
}

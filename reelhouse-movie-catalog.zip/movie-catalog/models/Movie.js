import mongoose from "mongoose";

const CastMemberSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    role: { type: String, trim: true, default: "" },
  },
  { _id: false }
);

const MovieSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
    description: { type: String, required: true },

    posterUrl: { type: String, required: true },
    backdropUrl: { type: String, default: "" },

    releaseYear: { type: Number, required: true, min: 1888, max: new Date().getFullYear() + 2 },
    language: { type: String, required: true },
    genres: [{ type: mongoose.Schema.Types.ObjectId, ref: "Genre", required: true }],
    runtime: { type: Number, required: true, min: 1 }, // minutes
    rating: { type: Number, min: 0, max: 10, default: 0 },
    quality: { type: String, default: "HD" }, // e.g. SD / HD / 4K label only, not a source claim

    director: { type: String, default: "" },
    cast: [CastMemberSchema],

    trailerUrl: { type: String, default: "" },
    videoUrl: { type: String, required: true }, // authorized stream URL only

    country: { type: String, default: "" },
    tags: [{ type: String, trim: true }],

    // --- Legal / rights gate -------------------------------------------------
    // These fields exist so the admin explicitly attests to the legal basis
    // for publishing each title. The API refuses to publish without them.
    rightsStatus: {
      type: String,
      enum: ["owned", "licensed", "public-domain", "creator-permission"],
      required: true,
    },
    licenseNote: { type: String, default: "" }, // e.g. license ID, agreement ref, PD source
    rightsConfirmed: { type: Boolean, default: false, required: true },

    featured: { type: Boolean, default: false },
    status: { type: String, enum: ["draft", "published"], default: "draft" },

    views: { type: Number, default: 0 },
  },
  { timestamps: true }
);

MovieSchema.index({ title: "text", description: "text", tags: "text" });
MovieSchema.index({ status: 1, releaseYear: -1 });
MovieSchema.index({ status: 1, featured: 1 });

export default mongoose.models.Movie || mongoose.model("Movie", MovieSchema);

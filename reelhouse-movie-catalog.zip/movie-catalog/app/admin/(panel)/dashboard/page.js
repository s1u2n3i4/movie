import Link from "next/link";
import Image from "next/image";
import { Film, Tags, Users, CheckCircle2, FileEdit } from "lucide-react";
import StatCard from "@/components/admin/StatCard";
import { connectDB } from "@/lib/db";
import Movie from "@/models/Movie";
import Genre from "@/models/Genre";
import Admin from "@/models/Admin";

export const metadata = { title: "Dashboard" };

export default async function AdminDashboardPage() {
  await connectDB();

  const [totalMovies, totalGenres, totalAdmins, published, drafts, recentMovies, mostViewed] =
    await Promise.all([
      Movie.countDocuments(),
      Genre.countDocuments(),
      Admin.countDocuments(),
      Movie.countDocuments({ status: "published" }),
      Movie.countDocuments({ status: "draft" }),
      Movie.find().sort({ createdAt: -1 }).limit(6).select("title slug posterUrl status createdAt").lean(),
      Movie.find({ status: "published" }).sort({ views: -1 }).limit(6).select("title slug posterUrl views").lean(),
      // (slug is used for edit links below, since the movie API is slug-keyed)
    ]);

  return (
    <div>
      <h1 className="mb-6 text-2xl text-bone">Dashboard</h1>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard label="Total movies" value={totalMovies} icon={Film} />
        <StatCard label="Published" value={published} icon={CheckCircle2} />
        <StatCard label="Drafts" value={drafts} icon={FileEdit} />
        <StatCard label="Genres" value={totalGenres} icon={Tags} />
        <StatCard label="Admin users" value={totalAdmins} icon={Users} />
      </div>

      <div className="mt-10 grid grid-cols-1 gap-8 lg:grid-cols-2">
        <div>
          <h2 className="mb-3 text-lg text-bone">Recently added</h2>
          <div className="card divide-y divide-line">
            {recentMovies.length === 0 && <p className="p-4 text-sm text-smoke">No movies yet.</p>}
            {recentMovies.map((m) => (
              <Link key={m._id} href={`/admin/movies/${m.slug}/edit`} className="flex items-center gap-3 p-3 hover:bg-panel2">
                <div className="relative h-14 w-10 shrink-0 overflow-hidden rounded bg-panel2">
                  {m.posterUrl && <Image src={m.posterUrl} alt="" fill className="object-cover" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-bone">{m.title}</p>
                  <p className="text-xs text-smoke">{new Date(m.createdAt).toLocaleDateString()}</p>
                </div>
                <span className={`badge ${m.status === "published" ? "border-marquee/40 text-marquee" : ""}`}>
                  {m.status}
                </span>
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-3 text-lg text-bone">Most viewed</h2>
          <div className="card divide-y divide-line">
            {mostViewed.length === 0 && <p className="p-4 text-sm text-smoke">No views recorded yet.</p>}
            {mostViewed.map((m) => (
              <Link key={m._id} href={`/admin/movies/${m.slug}/edit`} className="flex items-center gap-3 p-3 hover:bg-panel2">
                <div className="relative h-14 w-10 shrink-0 overflow-hidden rounded bg-panel2">
                  {m.posterUrl && <Image src={m.posterUrl} alt="" fill className="object-cover" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-bone">{m.title}</p>
                </div>
                <span className="badge">{m.views} views</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

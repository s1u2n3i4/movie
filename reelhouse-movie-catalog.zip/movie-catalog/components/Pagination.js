import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function Pagination({ page, pages, buildHref }) {
  if (pages <= 1) return null;

  return (
    <div className="mt-8 flex items-center justify-center gap-2">
      <Link
        href={buildHref(Math.max(1, page - 1))}
        aria-disabled={page <= 1}
        className={`btn-secondary px-3 py-2 ${page <= 1 ? "pointer-events-none opacity-40" : ""}`}
      >
        <ChevronLeft className="h-4 w-4" />
      </Link>
      <span className="px-3 text-sm text-smoke">
        Page {page} of {pages}
      </span>
      <Link
        href={buildHref(Math.min(pages, page + 1))}
        aria-disabled={page >= pages}
        className={`btn-secondary px-3 py-2 ${page >= pages ? "pointer-events-none opacity-40" : ""}`}
      >
        <ChevronRight className="h-4 w-4" />
      </Link>
    </div>
  );
}

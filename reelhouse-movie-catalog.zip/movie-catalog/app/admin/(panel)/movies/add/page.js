import MovieForm from "@/components/admin/MovieForm";
import { getGenres } from "@/lib/data";

export const metadata = { title: "Add Movie" };

export default async function AddMoviePage() {
  const genres = await getGenres();
  return (
    <div>
      <h1 className="mb-6 text-2xl text-bone">Add movie</h1>
      <MovieForm genres={genres} mode="add" />
    </div>
  );
}

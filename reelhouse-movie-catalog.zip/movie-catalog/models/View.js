import mongoose from "mongoose";

// One row per view event, kept lightweight for "most viewed" aggregation
// and simple analytics. Movie.views is an incrementing counter for fast reads;
// this collection lets you build time-windowed reports later if you want them.
const ViewSchema = new mongoose.Schema(
  {
    movie: { type: mongoose.Schema.Types.ObjectId, ref: "Movie", required: true, index: true },
    viewedAt: { type: Date, default: Date.now },
  },
  { timestamps: false }
);

export default mongoose.models.View || mongoose.model("View", ViewSchema);

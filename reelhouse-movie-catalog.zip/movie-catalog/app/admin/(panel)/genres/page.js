"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { Plus, Pencil, Trash2, Check, X } from "lucide-react";
import { apiFetch } from "@/lib/apiClient";

export default function AdminGenresPage() {
  const [genres, setGenres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState("");

  async function load() {
    setLoading(true);
    try {
      const data = await apiFetch("/api/genres");
      setGenres(data.genres);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function addGenre(e) {
    e.preventDefault();
    if (!newName.trim()) return;
    try {
      await apiFetch("/api/genres", { method: "POST", body: JSON.stringify({ name: newName.trim() }) });
      setNewName("");
      toast.success("Genre added.");
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  async function saveEdit(id) {
    try {
      await apiFetch(`/api/genres/${id}`, { method: "PUT", body: JSON.stringify({ name: editName.trim() }) });
      setEditingId(null);
      toast.success("Genre updated.");
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  async function remove(id, name) {
    if (!confirm(`Delete genre "${name}"?`)) return;
    try {
      await apiFetch(`/api/genres/${id}`, { method: "DELETE" });
      toast.success("Genre deleted.");
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  return (
    <div>
      <h1 className="mb-6 text-2xl text-bone">Genres</h1>

      <form onSubmit={addGenre} className="mb-6 flex gap-2">
        <input className="input max-w-xs" placeholder="New genre name" value={newName} onChange={(e) => setNewName(e.target.value)} />
        <button className="btn-primary"><Plus className="h-4 w-4" /> Add genre</button>
      </form>

      <div className="card divide-y divide-line">
        {loading && <p className="p-4 text-sm text-smoke">Loading…</p>}
        {!loading && genres.length === 0 && <p className="p-4 text-sm text-smoke">No genres yet — add one above.</p>}
        {genres.map((g) => (
          <div key={g._id} className="flex items-center justify-between gap-3 p-3">
            {editingId === g._id ? (
              <input className="input max-w-xs" value={editName} onChange={(e) => setEditName(e.target.value)} autoFocus />
            ) : (
              <div>
                <span className="text-bone">{g.name}</span>
                <span className="ml-2 text-xs text-smoke">{g.movieCount} movie{g.movieCount === 1 ? "" : "s"}</span>
              </div>
            )}
            <div className="flex gap-2">
              {editingId === g._id ? (
                <>
                  <button onClick={() => saveEdit(g._id)} className="btn-secondary px-2.5 py-1.5"><Check className="h-3.5 w-3.5" /></button>
                  <button onClick={() => setEditingId(null)} className="btn-secondary px-2.5 py-1.5"><X className="h-3.5 w-3.5" /></button>
                </>
              ) : (
                <>
                  <button onClick={() => { setEditingId(g._id); setEditName(g.name); }} className="btn-secondary px-2.5 py-1.5"><Pencil className="h-3.5 w-3.5" /></button>
                  <button onClick={() => remove(g._id, g.name)} className="btn-danger"><Trash2 className="h-3.5 w-3.5" /></button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

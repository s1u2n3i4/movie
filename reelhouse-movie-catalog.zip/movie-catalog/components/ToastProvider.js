"use client";

import { Toaster } from "react-hot-toast";

export default function ToastProvider() {
  return (
    <Toaster
      position="top-right"
      toastOptions={{
        style: {
          background: "#14161B",
          color: "#F3F1EA",
          border: "1px solid #23262E",
        },
        success: { iconTheme: { primary: "#E4A94E", secondary: "#0B0C10" } },
        error: { iconTheme: { primary: "#C1443C", secondary: "#0B0C10" } },
      }}
    />
  );
}

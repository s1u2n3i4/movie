import Link from "next/link";
import { Film } from "lucide-react";

export default function Footer({ copyrightNotice }) {
  const siteName = process.env.NEXT_PUBLIC_SITE_NAME || "Reelhouse";
  return (
    <footer className="mt-16 border-t border-line bg-panel/40">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
        <div className="flex flex-col gap-8 sm:flex-row sm:justify-between">
          <div className="max-w-sm">
            <div className="flex items-center gap-2">
              <Film className="h-5 w-5 text-marquee" />
              <span className="font-display text-xl tracking-widest">
                REEL<span className="text-marquee">HOUSE</span>
              </span>
            </div>
            <p className="mt-3 text-sm text-smoke">
              {copyrightNotice ||
                "All titles on this site are streamed under license, direct ownership, creator permission, or public-domain status."}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-8 text-sm sm:grid-cols-3">
            <div>
              <p className="mb-2 font-medium text-bone">Browse</p>
              <ul className="space-y-1.5 text-smoke">
                <li><Link href="/" className="hover:text-marquee">Home</Link></li>
                <li><Link href="/search" className="hover:text-marquee">Search</Link></li>
              </ul>
            </div>
            <div>
              <p className="mb-2 font-medium text-bone">Admin</p>
              <ul className="space-y-1.5 text-smoke">
                <li><Link href="/admin/login" className="hover:text-marquee">Admin login</Link></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-line pt-6 text-xs text-smoke">
          © {new Date().getFullYear()} {siteName}. All rights reserved by their respective owners.
        </div>
      </div>
    </footer>
  );
}

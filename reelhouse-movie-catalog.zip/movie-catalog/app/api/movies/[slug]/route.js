import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Movie from "@/models/Movie";
import Genre from "@/models/Genre";
import View from "@/models/View";
import { requireAdmin, getCurrentAdmin } from "@/lib/requireAdmin";
import { movieSchema } from "@/lib/validation";
import { uniqueSlug, toSlug } from "@/lib/slug";

async function findMovieAllowAdmin(slug) {
  const admin = await getCurrentAdmin();
  const filter = admin ? { slug } : { slug, status: "published" };
  return Movie.findOne(filter).populate("genres", "name slug");
}

// GET /api/movies/:slug — public detail page data. Logs a view for
// published titles (fire-and-forget counter bump).
export async function GET(_request, { params }) {
  await connectDB();
  const movie = await findMovieAllowAdmin(params.slug);
  if (!movie) return NextResponse.json({ error: "Movie not found." }, { status: 404 });

  if (movie.status === "published") {
    Movie.updateOne({ _id: movie._id }, { $inc: { views: 1 } }).catch(() => {});
    View.create({ movie: movie._id }).catch(() => {});
  }

  const related = await Movie.find({
    _id: { $ne: movie._id },
    status: "published",
    genres: { $in: movie.genres.map((g) => g._id) },
  })
    .limit(8)
    .select("title slug posterUrl releaseYear rating language quality")
    .lean();

  return NextResponse.json({ movie, related });
}

// PUT /api/movies/:slug — admin only, full update.
export async function PUT(request, { params }) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin", "editor"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  const parsed = movieSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Invalid movie data" },
      { status: 400 }
    );
  }
  const data = parsed.data;

  if (data.status === "published" && !data.rightsConfirmed) {
    return NextResponse.json(
      { error: "Cannot publish a movie without confirming legal rights to stream it." },
      { status: 400 }
    );
  }

  await connectDB();
  const existing = await Movie.findOne({ slug: params.slug });
  if (!existing) return NextResponse.json({ error: "Movie not found." }, { status: 404 });

  const genreDocs = await Genre.find({ _id: { $in: data.genres } });
  if (genreDocs.length !== data.genres.length) {
    return NextResponse.json({ error: "One or more genres are invalid." }, { status: 400 });
  }

  let slug = existing.slug;
  const desiredBase = data.slug ? toSlug(data.slug) : existing.slug;
  if (desiredBase !== existing.slug) {
    slug = await uniqueSlug(desiredBase, (candidate) =>
      Movie.exists({ slug: candidate, _id: { $ne: existing._id } })
    );
  }

  Object.assign(existing, data, { slug });
  await existing.save();

  return NextResponse.json({ movie: existing });
}

// DELETE /api/movies/:slug — admin only.
export async function DELETE(_request, { params }) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  await connectDB();
  const deleted = await Movie.findOneAndDelete({ slug: params.slug });
  if (!deleted) return NextResponse.json({ error: "Movie not found." }, { status: 404 });

  return NextResponse.json({ ok: true });
}

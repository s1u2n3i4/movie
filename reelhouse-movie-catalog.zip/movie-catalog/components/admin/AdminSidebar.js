"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Film, Tags, Users, LogOut, PlusCircle, ExternalLink } from "lucide-react";
import toast from "react-hot-toast";
import { apiFetch } from "@/lib/apiClient";

const links = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/movies", label: "Movies", icon: Film },
  { href: "/admin/movies/add", label: "Add Movie", icon: PlusCircle },
  { href: "/admin/genres", label: "Genres", icon: Tags },
  { href: "/admin/users", label: "Admin Users", icon: Users },
];

export default function AdminSidebar({ admin }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
      router.push("/admin/login");
      router.refresh();
    } catch {
      toast.error("Couldn't log out. Try again.");
    }
  }

  return (
    <aside className="flex h-screen w-64 shrink-0 flex-col border-r border-line bg-panel">
      <div className="border-b border-line p-5">
        <span className="font-display text-2xl tracking-widest text-bone">
          REEL<span className="text-marquee">HOUSE</span>
        </span>
        <p className="mt-0.5 text-xs uppercase tracking-wide text-smoke">Admin panel</p>
      </div>

      <nav className="flex-1 space-y-1 p-3">
        {links.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || (href !== "/admin/dashboard" && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-2.5 rounded-md px-3 py-2.5 text-sm transition ${
                active ? "bg-marquee/10 text-marquee" : "text-smoke hover:bg-panel2 hover:text-bone"
              }`}
            >
              <Icon className="h-4 w-4" /> {label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-line p-3">
        <Link
          href="/"
          target="_blank"
          className="flex items-center gap-2.5 rounded-md px-3 py-2.5 text-sm text-smoke hover:bg-panel2 hover:text-bone"
        >
          <ExternalLink className="h-4 w-4" /> View site
        </Link>
        {admin && (
          <div className="mt-1 px-3 py-1.5 text-xs text-smoke">
            Signed in as <span className="text-bone">{admin.username}</span> · {admin.role}
          </div>
        )}
        <button
          onClick={logout}
          className="mt-1 flex w-full items-center gap-2.5 rounded-md px-3 py-2.5 text-sm text-velvet hover:bg-velvet/10"
        >
          <LogOut className="h-4 w-4" /> Log out
        </button>
      </div>
    </aside>
  );
}

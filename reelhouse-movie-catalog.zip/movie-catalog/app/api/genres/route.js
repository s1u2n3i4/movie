import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Genre from "@/models/Genre";
import Movie from "@/models/Movie";
import { requireAdmin } from "@/lib/requireAdmin";
import { genreSchema } from "@/lib/validation";
import { uniqueSlug, toSlug } from "@/lib/slug";

// GET /api/genres — public. Includes a published-movie count per genre,
// which the admin dashboard and public nav both use.
export async function GET() {
  await connectDB();
  const genres = await Genre.find().sort({ name: 1 }).lean();

  const counts = await Movie.aggregate([
    { $match: { status: "published" } },
    { $unwind: "$genres" },
    { $group: { _id: "$genres", count: { $sum: 1 } } },
  ]);
  const countMap = Object.fromEntries(counts.map((c) => [c._id.toString(), c.count]));

  const withCounts = genres.map((g) => ({ ...g, movieCount: countMap[g._id.toString()] || 0 }));
  return NextResponse.json({ genres: withCounts });
}

// POST /api/genres — admin only.
export async function POST(request) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  const parsed = genreSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
  }

  await connectDB();
  const base = parsed.data.slug ? parsed.data.slug : toSlug(parsed.data.name);
  const slug = await uniqueSlug(base, (candidate) => Genre.exists({ slug: candidate }));

  try {
    const genre = await Genre.create({ ...parsed.data, slug });
    return NextResponse.json({ genre }, { status: 201 });
  } catch (err) {
    if (err?.code === 11000) {
      return NextResponse.json({ error: "That genre already exists." }, { status: 409 });
    }
    return NextResponse.json({ error: "Failed to create genre." }, { status: 500 });
  }
}

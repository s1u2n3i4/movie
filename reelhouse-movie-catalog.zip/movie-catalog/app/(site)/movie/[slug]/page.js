import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { Star, Clock, Calendar, Globe } from "lucide-react";
import { getMovieBySlug } from "@/lib/data";
import VideoPlayer from "@/components/VideoPlayer";
import MovieGrid from "@/components/MovieGrid";
import SectionHeader from "@/components/SectionHeader";

export async function generateMetadata({ params }) {
  const movie = await getMovieBySlug(params.slug);
  if (!movie) return { title: "Movie not found" };

  const description = movie.description?.slice(0, 155);
  return {
    title: movie.title,
    description,
    openGraph: {
      title: movie.title,
      description,
      images: movie.posterUrl ? [{ url: movie.posterUrl }] : [],
      type: "video.movie",
    },
    twitter: { card: "summary_large_image", title: movie.title, description },
  };
}

export default async function MoviePage({ params }) {
  // countView: true logs a view each render; fine for a low-to-mid traffic
  // catalog. For high traffic, move this to a client-side beacon instead.
  const movie = await getMovieBySlug(params.slug, { countView: true });
  if (!movie) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Movie",
    name: movie.title,
    description: movie.description,
    image: movie.posterUrl,
    dateCreated: String(movie.releaseYear),
    duration: `PT${movie.runtime}M`,
    genre: movie.genres.map((g) => g.name),
    director: movie.director ? { "@type": "Person", name: movie.director } : undefined,
  };

  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {movie.backdropUrl && (
        <div className="relative h-[38vh] min-h-[220px] w-full overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${movie.backdropUrl})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/60 to-ink/20" />
        </div>
      )}

      <div className={`mx-auto max-w-7xl px-4 sm:px-6 ${movie.backdropUrl ? "-mt-24" : "pt-10"} relative pb-16`}>
        <div className="grid grid-cols-1 gap-8 md:grid-cols-[260px_1fr]">
          <div className="mx-auto w-48 shrink-0 md:mx-0 md:w-full">
            <div className="relative aspect-[2/3] overflow-hidden rounded-card border border-line shadow-card">
              <Image src={movie.posterUrl} alt={`${movie.title} poster`} fill sizes="260px" className="object-cover" />
            </div>
          </div>

          <div>
            <h1 className="font-display text-4xl tracking-wide text-bone sm:text-5xl">{movie.title}</h1>

            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-smoke">
              <span className="flex items-center gap-1"><Calendar className="h-4 w-4" /> {movie.releaseYear}</span>
              <span className="flex items-center gap-1"><Clock className="h-4 w-4" /> {movie.runtime} min</span>
              <span className="flex items-center gap-1"><Globe className="h-4 w-4" /> {movie.language}</span>
              {movie.rating > 0 && (
                <span className="flex items-center gap-1 text-marquee">
                  <Star className="h-4 w-4 fill-marquee" /> {movie.rating.toFixed(1)}
                </span>
              )}
              <span className="badge">{movie.quality}</span>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {movie.genres.map((g) => (
                <Link key={g.slug} href={`/genre/${g.slug}`} className="badge hover:border-marquee/60 hover:text-marquee">
                  {g.name}
                </Link>
              ))}
            </div>

            <p className="mt-5 max-w-3xl leading-relaxed text-bone/90">{movie.description}</p>

            {movie.director && (
              <p className="mt-4 text-sm text-smoke"><span className="text-bone">Director:</span> {movie.director}</p>
            )}
            {movie.cast?.length > 0 && (
              <p className="mt-1 text-sm text-smoke">
                <span className="text-bone">Cast:</span>{" "}
                {movie.cast.map((c) => c.role ? `${c.name} (${c.role})` : c.name).join(", ")}
              </p>
            )}
            {movie.country && (
              <p className="mt-1 text-sm text-smoke"><span className="text-bone">Country:</span> {movie.country}</p>
            )}

            <div className="mt-8">
              <h2 className="mb-3 text-xl text-bone">Watch</h2>
              <VideoPlayer url={movie.videoUrl} title={movie.title} />
            </div>

            {movie.trailerUrl && (
              <div className="mt-8">
                <h2 className="mb-3 text-xl text-bone">Trailer</h2>
                <VideoPlayer url={movie.trailerUrl} title={`${movie.title} trailer`} />
              </div>
            )}
          </div>
        </div>

        {movie.related?.length > 0 && (
          <div className="mt-16">
            <SectionHeader title="You might also like" />
            <MovieGrid movies={movie.related} />
          </div>
        )}
      </div>
    </div>
  );
}

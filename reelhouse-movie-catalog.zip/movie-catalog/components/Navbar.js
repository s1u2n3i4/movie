"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Menu, X, Search, Film } from "lucide-react";

export default function Navbar({ genres = [] }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const router = useRouter();

  function submitSearch(e) {
    e.preventDefault();
    if (!q.trim()) return;
    router.push(`/search?query=${encodeURIComponent(q.trim())}`);
    setOpen(false);
  }

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-ink/90 backdrop-blur">
      <div className="marquee-rule" />
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <Film className="h-6 w-6 text-marquee" strokeWidth={2.2} />
          <span className="font-display text-2xl leading-none tracking-widest text-bone">
            REEL<span className="text-marquee">HOUSE</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm text-smoke lg:flex">
          <Link href="/" className="hover:text-marquee transition">Home</Link>
          <div className="group relative">
            <button className="hover:text-marquee transition">Genres</button>
            <div className="invisible absolute left-0 top-full z-50 w-64 rounded-card border border-line bg-panel p-2 opacity-0 shadow-card transition group-hover:visible group-hover:opacity-100">
              <div className="grid grid-cols-2 gap-1">
                {genres.slice(0, 12).map((g) => (
                  <Link
                    key={g.slug}
                    href={`/genre/${g.slug}`}
                    className="rounded px-2 py-1.5 text-sm hover:bg-panel2 hover:text-marquee"
                  >
                    {g.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
          <Link href="/search" className="hover:text-marquee transition">Browse</Link>
        </nav>

        <form onSubmit={submitSearch} className="ml-auto hidden max-w-sm flex-1 items-center lg:flex">
          <div className="relative w-full">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-smoke" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search titles, genres, years…"
              className="input pl-9 py-2"
              aria-label="Search movies"
            />
          </div>
        </form>

        <button
          className="ml-auto rounded-md border border-line p-2 lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-line bg-ink px-4 pb-4 pt-2 lg:hidden">
          <form onSubmit={submitSearch} className="mb-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-smoke" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search titles…"
                className="input pl-9"
              />
            </div>
          </form>
          <div className="flex flex-col gap-1 text-sm">
            <Link href="/" onClick={() => setOpen(false)} className="rounded px-2 py-2 hover:bg-panel2">Home</Link>
            <Link href="/search" onClick={() => setOpen(false)} className="rounded px-2 py-2 hover:bg-panel2">Browse</Link>
            <p className="mt-2 px-2 text-xs uppercase tracking-wide text-smoke">Genres</p>
            <div className="grid grid-cols-2 gap-1">
              {genres.map((g) => (
                <Link
                  key={g.slug}
                  href={`/genre/${g.slug}`}
                  onClick={() => setOpen(false)}
                  className="rounded px-2 py-2 hover:bg-panel2 hover:text-marquee"
                >
                  {g.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

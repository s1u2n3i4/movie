import { connectDB } from "@/lib/db";
import Movie from "@/models/Movie";
import Genre from "@/models/Genre";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export default async function sitemap() {
  await connectDB();

  const [movies, genres] = await Promise.all([
    Movie.find({ status: "published" }).select("slug updatedAt").lean(),
    Genre.find().select("slug updatedAt").lean(),
  ]);

  const staticRoutes = ["", "/search"].map((path) => ({
    url: `${siteUrl}${path}`,
    lastModified: new Date(),
  }));

  const movieRoutes = movies.map((m) => ({
    url: `${siteUrl}/movie/${m.slug}`,
    lastModified: m.updatedAt,
  }));

  const genreRoutes = genres.map((g) => ({
    url: `${siteUrl}/genre/${g.slug}`,
    lastModified: g.updatedAt,
  }));

  return [...staticRoutes, ...movieRoutes, ...genreRoutes];
}

import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { connectDB } from "@/lib/db";
import Admin from "@/models/Admin";
import { signSession, sessionCookieOptions, COOKIE_NAME } from "@/lib/auth";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";
import { loginSchema } from "@/lib/validation";

export async function POST(request) {
  const ip = getClientIp(request);
  const rate = checkRateLimit(ip);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: "Too many login attempts. Try again later." },
      { status: 429 }
    );
  }

  const body = await request.json().catch(() => null);
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Invalid input" },
      { status: 400 }
    );
  }

  const { identifier, password } = parsed.data;

  await connectDB();
  const admin = await Admin.findOne({
    $or: [{ username: identifier.toLowerCase() }, { email: identifier.toLowerCase() }],
  });

  // Same error for "not found" and "wrong password" so we don't leak
  // which usernames exist.
  if (!admin || !admin.isActive) {
    return NextResponse.json({ error: "Invalid credentials." }, { status: 401 });
  }

  const valid = await admin.verifyPassword(password);
  if (!valid) {
    return NextResponse.json({ error: "Invalid credentials." }, { status: 401 });
  }

  admin.lastLoginAt = new Date();
  await admin.save();

  const token = signSession(admin);
  cookies().set(COOKIE_NAME, token, sessionCookieOptions());

  return NextResponse.json({
    admin: { username: admin.username, email: admin.email, role: admin.role },
  });
}

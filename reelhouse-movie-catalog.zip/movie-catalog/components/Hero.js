import Link from "next/link";
import { Play, Info, Star } from "lucide-react";

export default function Hero({ movie }) {
  if (!movie) return null;

  const backdrop = movie.backdropUrl || movie.posterUrl;

  return (
    <section className="relative h-[62vh] min-h-[420px] w-full overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${backdrop})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/70 to-ink/10" />
      <div className="absolute inset-0 bg-gradient-to-r from-ink/90 via-ink/30 to-transparent" />

      <div className="relative mx-auto flex h-full max-w-7xl flex-col justify-end px-4 pb-12 sm:px-6">
        <span className="badge mb-3 w-fit border-marquee/40 bg-marquee/10 text-marquee">Featured</span>
        <h1 className="max-w-2xl font-display text-5xl leading-none tracking-wide text-bone sm:text-6xl">
          {movie.title}
        </h1>
        <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-smoke">
          <span>{movie.releaseYear}</span>
          <span>·</span>
          <span>{movie.language}</span>
          <span>·</span>
          <span>{movie.runtime} min</span>
          {movie.rating > 0 && (
            <>
              <span>·</span>
              <span className="flex items-center gap-1 text-marquee">
                <Star className="h-4 w-4 fill-marquee" /> {movie.rating.toFixed(1)}
              </span>
            </>
          )}
        </div>
        <p className="mt-4 max-w-xl text-smoke line-clamp-3">{movie.description}</p>
        <div className="mt-6 flex gap-3">
          <Link href={`/movie/${movie.slug}`} className="btn-primary">
            <Play className="h-4 w-4 fill-ink" /> Watch now
          </Link>
          <Link href={`/movie/${movie.slug}`} className="btn-secondary">
            <Info className="h-4 w-4" /> More info
          </Link>
        </div>
      </div>
    </section>
  );
}

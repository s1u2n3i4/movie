import Link from "next/link";
import { ChevronRight } from "lucide-react";

export default function SectionHeader({ title, href, hrefLabel = "See all" }) {
  return (
    <div className="mb-4 flex items-end justify-between">
      <h2 className="text-2xl text-bone">{title}</h2>
      {href && (
        <Link href={href} className="flex items-center gap-1 text-sm text-smoke hover:text-marquee">
          {hrefLabel} <ChevronRight className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}

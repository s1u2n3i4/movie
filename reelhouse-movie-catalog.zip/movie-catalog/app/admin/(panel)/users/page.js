"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { Plus, Trash2, ShieldCheck } from "lucide-react";
import { apiFetch } from "@/lib/apiClient";

const ROLES = ["superadmin", "admin", "editor"];

export default function AdminUsersPage() {
  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [forbidden, setForbidden] = useState(false);
  const [form, setForm] = useState({ username: "", email: "", password: "", role: "admin" });
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const data = await apiFetch("/api/admin/users");
      setAdmins(data.admins);
    } catch (err) {
      if (err.message.includes("permission")) setForbidden(true);
      else toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function createAdmin(e) {
    e.preventDefault();
    setCreating(true);
    try {
      await apiFetch("/api/admin/users", { method: "POST", body: JSON.stringify(form) });
      toast.success("Admin created.");
      setForm({ username: "", email: "", password: "", role: "admin" });
      load();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setCreating(false);
    }
  }

  async function changeRole(id, role) {
    try {
      await apiFetch(`/api/admin/users/${id}`, { method: "PUT", body: JSON.stringify({ role }) });
      toast.success("Role updated.");
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  async function remove(id, username) {
    if (!confirm(`Remove admin "${username}"?`)) return;
    try {
      await apiFetch(`/api/admin/users/${id}`, { method: "DELETE" });
      toast.success("Admin removed.");
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  if (forbidden) {
    return (
      <div className="card p-6 text-center text-smoke">
        Only the main administrator (superadmin) can manage admin users.
      </div>
    );
  }

  return (
    <div>
      <h1 className="mb-6 flex items-center gap-2 text-2xl text-bone">
        <ShieldCheck className="h-6 w-6 text-marquee" /> Admin users
      </h1>

      <form onSubmit={createAdmin} className="card mb-8 grid grid-cols-1 gap-3 p-5 sm:grid-cols-2 lg:grid-cols-5">
        <input className="input" placeholder="Username" value={form.username} onChange={(e) => setForm((f) => ({ ...f, username: e.target.value }))} required />
        <input className="input" placeholder="Email" type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} required />
        <input className="input" placeholder="Password (min 8 chars)" type="password" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} required />
        <select className="input" value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}>
          {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
        </select>
        <button disabled={creating} className="btn-primary"><Plus className="h-4 w-4" /> {creating ? "Adding…" : "Add admin"}</button>
      </form>

      <div className="card divide-y divide-line">
        {loading && <p className="p-4 text-sm text-smoke">Loading…</p>}
        {!loading && admins.map((a) => (
          <div key={a._id} className="flex flex-wrap items-center justify-between gap-3 p-3">
            <div>
              <p className="text-bone">{a.username} <span className="text-xs text-smoke">({a.email})</span></p>
              <p className="text-xs text-smoke">{a.isActive ? "Active" : "Deactivated"} · last login {a.lastLoginAt ? new Date(a.lastLoginAt).toLocaleString() : "never"}</p>
            </div>
            <div className="flex items-center gap-2">
              <select className="input w-auto" value={a.role} onChange={(e) => changeRole(a._id, e.target.value)}>
                {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
              <button onClick={() => remove(a._id, a.username)} className="btn-danger"><Trash2 className="h-3.5 w-3.5" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

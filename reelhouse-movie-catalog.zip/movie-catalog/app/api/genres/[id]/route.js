import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import Genre from "@/models/Genre";
import Movie from "@/models/Movie";
import { requireAdmin } from "@/lib/requireAdmin";
import { genreSchema } from "@/lib/validation";
import { uniqueSlug, toSlug } from "@/lib/slug";

export async function PUT(request, { params }) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  const body = await request.json().catch(() => null);
  const parsed = genreSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
  }

  await connectDB();
  const genre = await Genre.findById(params.id);
  if (!genre) return NextResponse.json({ error: "Genre not found." }, { status: 404 });

  let slug = genre.slug;
  const desiredBase = parsed.data.slug ? toSlug(parsed.data.slug) : genre.slug;
  if (desiredBase !== genre.slug) {
    slug = await uniqueSlug(desiredBase, (candidate) =>
      Genre.exists({ slug: candidate, _id: { $ne: genre._id } })
    );
  }

  Object.assign(genre, parsed.data, { slug });
  await genre.save();
  return NextResponse.json({ genre });
}

export async function DELETE(_request, { params }) {
  const { admin, error, status } = await requireAdmin(["superadmin", "admin"]);
  if (!admin) return NextResponse.json({ error }, { status });

  await connectDB();
  const inUse = await Movie.exists({ genres: params.id });
  if (inUse) {
    return NextResponse.json(
      { error: "Can't delete a genre that's still assigned to movies. Reassign those movies first." },
      { status: 409 }
    );
  }

  const deleted = await Genre.findByIdAndDelete(params.id);
  if (!deleted) return NextResponse.json({ error: "Genre not found." }, { status: 404 });

  return NextResponse.json({ ok: true });
}
